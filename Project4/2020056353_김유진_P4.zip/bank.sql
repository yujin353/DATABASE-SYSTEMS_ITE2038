-- --------------------------------------------------------
-- 호스트:                          127.0.0.1
-- 서버 버전:                        8.0.27 - MySQL Community Server - GPL
-- 서버 OS:                        Win64
-- HeidiSQL 버전:                  11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- bank 데이터베이스 구조 내보내기
DROP DATABASE IF EXISTS `bank`;
CREATE DATABASE IF NOT EXISTS `bank` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bank`;

-- 테이블 bank.거래기록 구조 내보내기
DROP TABLE IF EXISTS `거래기록`;
CREATE TABLE IF NOT EXISTS `거래기록` (
  `거래계좌번호` int NOT NULL,
  `거래번호` int NOT NULL,
  `거래금액` int NOT NULL,
  `거래날짜` date NOT NULL,
  PRIMARY KEY (`거래계좌번호`,`거래번호`),
  CONSTRAINT `거래기록_ibfk_1` FOREIGN KEY (`거래계좌번호`) REFERENCES `계좌` (`계좌번호`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.거래기록:~0 rows (대략적) 내보내기
DELETE FROM `거래기록`;
/*!40000 ALTER TABLE `거래기록` DISABLE KEYS */;
INSERT INTO `거래기록` (`거래계좌번호`, `거래번호`, `거래금액`, `거래날짜`) VALUES
	(300204, 1, 100000, '2021-12-03'),
	(300204, 2, 3000, '2021-12-03'),
	(300402, 1, 40000, '2021-12-03'),
	(489142, 1, 3000, '2021-12-02'),
	(489142, 2, 10000, '2021-12-02'),
	(489142, 3, 30000, '2021-12-02'),
	(490185, 1, 100000, '2021-12-02'),
	(490185, 2, 49000, '2021-12-02'),
	(490185, 9, 9000, '2021-12-02'),
	(492413, 1, 932000, '2021-12-03'),
	(492413, 2, 12000, '2021-12-03'),
	(492413, 3, 120000, '2021-12-03'),
	(908240, 1, 300000, '2021-12-02'),
	(908240, 2, 48000, '2021-12-02'),
	(908240, 3, 90832, '2021-12-02'),
	(3001053, 3, 40000, '2021-12-03'),
	(3302143, 1, 110000, '2021-12-03'),
	(3302143, 2, 29000, '2021-12-03'),
	(3302143, 3, 29999, '2021-12-03'),
	(3772837, 4, 303030, '2021-12-03'),
	(3772837, 5, 3030, '2021-12-03'),
	(3992034, 1, 332000, '2021-12-03'),
	(3992034, 2, 8000, '2021-12-03'),
	(4413242, 1, 4000, '2021-12-03'),
	(8883992, 1, 5000500, '2021-12-03'),
	(8883992, 2, 49500, '2021-12-03');
/*!40000 ALTER TABLE `거래기록` ENABLE KEYS */;

-- 테이블 bank.계좌 구조 내보내기
DROP TABLE IF EXISTS `계좌`;
CREATE TABLE IF NOT EXISTS `계좌` (
  `계좌번호` int NOT NULL,
  `개설일자` date DEFAULT NULL,
  `비밀번호` int NOT NULL,
  `잔액` int NOT NULL,
  `개설예금주` int NOT NULL,
  `삭제예금주` int DEFAULT NULL,
  `입출금예금주` int DEFAULT NULL,
  PRIMARY KEY (`계좌번호`),
  KEY `개설예금주` (`개설예금주`),
  KEY `삭제예금주` (`삭제예금주`),
  KEY `입출금예금주` (`입출금예금주`),
  CONSTRAINT `계좌_ibfk_1` FOREIGN KEY (`개설예금주`) REFERENCES `사용자` (`사용자등록번호`),
  CONSTRAINT `계좌_ibfk_2` FOREIGN KEY (`삭제예금주`) REFERENCES `사용자` (`사용자등록번호`),
  CONSTRAINT `계좌_ibfk_3` FOREIGN KEY (`입출금예금주`) REFERENCES `사용자` (`사용자등록번호`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.계좌:~0 rows (대략적) 내보내기
DELETE FROM `계좌`;
/*!40000 ALTER TABLE `계좌` DISABLE KEYS */;
INSERT INTO `계좌` (`계좌번호`, `개설일자`, `비밀번호`, `잔액`, `개설예금주`, `삭제예금주`, `입출금예금주`) VALUES
	(300204, '2021-12-03', 3321, 140000, 383822, 383822, 383822),
	(300402, '2021-12-03', 1212, 40000, 399402, 399402, 399402),
	(480912, '2021-12-02', 4001, 0, 39014, 39014, 39014),
	(489142, '2021-12-02', 1234, 93000, 480, 480, 480),
	(490185, '2021-12-02', 133, 99000, 39014, 39014, 39014),
	(492413, '2021-12-03', 4279, 800000, 105020, 105020, 105020),
	(908240, '2021-12-02', 333, 257168, 48914, 48914, 48914),
	(3001053, '2021-12-03', 4243, 40000, 200401, 200401, 200401),
	(3302143, '2021-12-03', 5532, 109001, 3321, 3321, 3321),
	(3772837, '2021-12-03', 777, 300000, 388929, 388929, 388929),
	(3992034, '2021-12-03', 1234, 340000, 200401, 200401, 200401),
	(4413242, '2021-12-03', 4423, 4000, 3321, 3321, 3321),
	(8883992, '2021-12-03', 4444, 5050000, 388929, 388929, 388929);
/*!40000 ALTER TABLE `계좌` ENABLE KEYS */;

-- 테이블 bank.계좌관리 구조 내보내기
DROP TABLE IF EXISTS `계좌관리`;
CREATE TABLE IF NOT EXISTS `계좌관리` (
  `계좌번호` int NOT NULL,
  `관리자번호` int NOT NULL,
  PRIMARY KEY (`계좌번호`,`관리자번호`),
  KEY `관리자번호` (`관리자번호`),
  CONSTRAINT `계좌관리_ibfk_1` FOREIGN KEY (`계좌번호`) REFERENCES `계좌` (`계좌번호`),
  CONSTRAINT `계좌관리_ibfk_2` FOREIGN KEY (`관리자번호`) REFERENCES `관리자` (`관리자등록번호`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.계좌관리:~0 rows (대략적) 내보내기
DELETE FROM `계좌관리`;
/*!40000 ALTER TABLE `계좌관리` DISABLE KEYS */;
INSERT INTO `계좌관리` (`계좌번호`, `관리자번호`) VALUES
	(908240, 39013),
	(480912, 39015),
	(490185, 39015),
	(489142, 93014),
	(492413, 302050),
	(300204, 330201),
	(3001053, 390284),
	(3992034, 390284),
	(3772837, 393223),
	(8883992, 393223),
	(300402, 3829501);
/*!40000 ALTER TABLE `계좌관리` ENABLE KEYS */;

-- 테이블 bank.관리자 구조 내보내기
DROP TABLE IF EXISTS `관리자`;
CREATE TABLE IF NOT EXISTS `관리자` (
  `관리자이름` varchar(15) NOT NULL,
  `관리자등록번호` int NOT NULL,
  `주민등록번호` int NOT NULL,
  `주소` varchar(15) NOT NULL,
  `연락처` int NOT NULL,
  `근무은행번호` int NOT NULL,
  PRIMARY KEY (`관리자등록번호`),
  UNIQUE KEY `주민등록번호` (`주민등록번호`),
  KEY `근무은행번호` (`근무은행번호`),
  CONSTRAINT `관리자_ibfk_1` FOREIGN KEY (`근무은행번호`) REFERENCES `은행` (`은행번호`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.관리자:~0 rows (대략적) 내보내기
DELETE FROM `관리자`;
/*!40000 ALTER TABLE `관리자` DISABLE KEYS */;
INSERT INTO `관리자` (`관리자이름`, `관리자등록번호`, `주민등록번호`, `주소`, `연락처`, `근무은행번호`) VALUES
	('김지원', 2905, 389204, '여의도', 30184, 3),
	('김수한', 7077, 800808, '신논현', 103323, 1),
	('김은우', 8822, 880707, '인천', 10100101, 3),
	('김수민', 19919, 389284, '강동', 1049920, 3),
	('신은숙', 30291, 893232, '위례', 1020023, 1),
	('김이영', 39013, 930284, '이천', 1019302, 2),
	('김정윤', 39015, 903852, '여의도', 1019320, 1),
	('김하나', 48204, 849253, '길동', 1040294, 4),
	('김유진', 93014, 920814, '위례', 104892, 1),
	('강이주', 302050, 930123, '동작구33길', 102203, 1),
	('김규림', 330201, 900102, '상암동', 102202, 1),
	('김은형', 332211, 993322, '강남', 100332, 2),
	('은가영', 390284, 898989, '강동', 104092333, 4),
	('김미희', 393223, 8981793, '을지로', 10100101, 3),
	('김은희', 393939, 88888, '서초', 1003902, 2),
	('박정은', 399200, 992222, '고양', 10010003, 2),
	('신유진', 801932, 302401, '서초', 102203, 1),
	('박영은', 829104, 880909, '시청33', 10103203, 1),
	('이은영', 900203, 801120, '구파발', 102203, 1),
	('서강해', 3829501, 880205, '여의도', 102204, 1),
	('김영국', 3910492, 782993, '강남', 104092, 3),
	('김은희', 9393949, 7728739, '강남', 10390288, 1);
/*!40000 ALTER TABLE `관리자` ENABLE KEYS */;

-- 테이블 bank.사용자 구조 내보내기
DROP TABLE IF EXISTS `사용자`;
CREATE TABLE IF NOT EXISTS `사용자` (
  `사용자이름` varchar(15) NOT NULL,
  `사용자등록번호` int NOT NULL,
  `주민등록번호` int NOT NULL,
  `연락처` int NOT NULL,
  `주소` varchar(15) NOT NULL,
  PRIMARY KEY (`사용자등록번호`),
  UNIQUE KEY `주민등록번호` (`주민등록번호`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.사용자:~0 rows (대략적) 내보내기
DELETE FROM `사용자`;
/*!40000 ALTER TABLE `사용자` DISABLE KEYS */;
INSERT INTO `사용자` (`사용자이름`, `사용자등록번호`, `주민등록번호`, `연락처`, `주소`) VALUES
	('김지영', 480, 928950, 104892, '시청'),
	('한가람', 3321, 880220, 102202202, '위례'),
	('신지영', 39014, 94021, 10402, '위례'),
	('김미숙', 48914, 9308240, 10482, '을지로'),
	('한서주', 105020, 920140, 1022064, '시청22길'),
	('박영희', 200401, 930201, 102203, '여의도39길'),
	('이유림', 383822, 800204, 10204060, '강남224길'),
	('하기원', 388929, 902803, 10390284, '응암'),
	('고연희', 399402, 930206, 10229304, '강남33길');
/*!40000 ALTER TABLE `사용자` ENABLE KEYS */;

-- 테이블 bank.사용자관리 구조 내보내기
DROP TABLE IF EXISTS `사용자관리`;
CREATE TABLE IF NOT EXISTS `사용자관리` (
  `관리자번호` int NOT NULL,
  `사용자번호` int NOT NULL,
  PRIMARY KEY (`관리자번호`,`사용자번호`),
  KEY `사용자번호` (`사용자번호`),
  CONSTRAINT `사용자관리_ibfk_1` FOREIGN KEY (`관리자번호`) REFERENCES `관리자` (`관리자등록번호`),
  CONSTRAINT `사용자관리_ibfk_2` FOREIGN KEY (`사용자번호`) REFERENCES `사용자` (`사용자등록번호`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.사용자관리:~0 rows (대략적) 내보내기
DELETE FROM `사용자관리`;
/*!40000 ALTER TABLE `사용자관리` DISABLE KEYS */;
INSERT INTO `사용자관리` (`관리자번호`, `사용자번호`) VALUES
	(30291, 480),
	(93014, 480),
	(801932, 480),
	(829104, 480),
	(900203, 480),
	(39015, 39014),
	(39013, 48914),
	(332211, 48914),
	(302050, 105020),
	(390284, 200401),
	(302050, 383822),
	(330201, 383822),
	(393223, 388929),
	(3829501, 399402);
/*!40000 ALTER TABLE `사용자관리` ENABLE KEYS */;

-- 테이블 bank.은행 구조 내보내기
DROP TABLE IF EXISTS `은행`;
CREATE TABLE IF NOT EXISTS `은행` (
  `은행번호` int NOT NULL,
  `은행이름` varchar(15) NOT NULL,
  PRIMARY KEY (`은행번호`),
  UNIQUE KEY `은행이름` (`은행이름`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.은행:~0 rows (대략적) 내보내기
DELETE FROM `은행`;
/*!40000 ALTER TABLE `은행` DISABLE KEYS */;
INSERT INTO `은행` (`은행번호`, `은행이름`) VALUES
	(1, '국민은행'),
	(3, '농협은행'),
	(4, '신한은행'),
	(2, '하나은행');
/*!40000 ALTER TABLE `은행` ENABLE KEYS */;

-- 테이블 bank.지점 구조 내보내기
DROP TABLE IF EXISTS `지점`;
CREATE TABLE IF NOT EXISTS `지점` (
  `소속은행번호` int NOT NULL,
  `지점번호` int NOT NULL,
  `지점이름` varchar(15) NOT NULL,
  `지점주소` varchar(15) NOT NULL,
  PRIMARY KEY (`소속은행번호`,`지점번호`),
  CONSTRAINT `지점_ibfk_1` FOREIGN KEY (`소속은행번호`) REFERENCES `은행` (`은행번호`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 데이터 bank.지점:~0 rows (대략적) 내보내기
DELETE FROM `지점`;
/*!40000 ALTER TABLE `지점` DISABLE KEYS */;
INSERT INTO `지점` (`소속은행번호`, `지점번호`, `지점이름`, `지점주소`) VALUES
	(1, 1, '시청점', '시청34길'),
	(1, 2, '강남점', '강남82길'),
	(1, 3, '여의도점', '여의도25길'),
	(1, 4, '을지로점', '을지로43길'),
	(1, 5, '서초점', '서초33'),
	(2, 4, '을지로점', '을지로54길'),
	(3, 2, '강남점', '강남82길'),
	(3, 5, '서초점', '서초33'),
	(4, 6, '강동점', '강동84길');
/*!40000 ALTER TABLE `지점` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
