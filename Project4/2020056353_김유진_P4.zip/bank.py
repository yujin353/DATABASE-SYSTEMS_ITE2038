import pymysql as pms
import datetime

#DBMS와 connection 만듦
connection = pms.connect(
    host = 'localhost',
    port = 3306,
    user = 'root',
    password = '1234',
    db = 'bank'
)

connection

#커서 만들기
cursor = connection.cursor()

print('당신은 은행원입니다.\n이름을 입력하세요')
clerkName = input()
print('당신이 일하는 은행을 입력하세요')
print('국민은행(1), 하나은행(2), 농협은행(3), 신한은행(4)')
bankName = input()
if bankName == '국민은행':
    bankNum = 1
elif bankName == '하나은행':
    bankNum = 2
elif bankName == '농협은행':
    bankNum = 3
elif bankName == '신한은행':
    bankNum = 4

#은행 테이블에 은행정보 입력하기
sql = "INSERT IGNORE INTO 은행 VALUES (%s, %s)"
cursor.execute(sql, (bankNum, bankName))
cursor.fetchall()
connection.commit()


print('당신이 일하는 지점을 입력하세요')
print('시청점(1), 강남점(2), 여의도점(3), 을지로점(4), 서초점(5), 강동점(6)')
branchName = input()
if branchName == '시청점':
    branchNum = 1
elif branchName == '강남점':
    branchNum = 2
elif branchName == '여의도점':
    branchNum = 3
elif branchName == '을지로점':
    branchNum = 4
elif branchName == '서초점':
    branchNum = 5
elif branchName == '강동점':
    branchNum = 6
    
print('당신이 일하는 지점의 주소를 입력하세요')
branchLocation = input()

#지점 테이블에 지점정보 입력하기
sql = "INSERT IGNORE INTO 지점 VALUES (%s, %s, %s, %s)"
cursor.execute(sql, (bankNum, branchNum, branchName, branchLocation))
cursor.fetchall()
connection.commit()


print('관리자등록번호를 입력하세요')
clerkNum = int(input())
print('주민등록번호를 입력하세요')
clerkSsn = int(input())
print('주소를 입력하세요')
clerkAddress = input()
print('연락처를 입력하세요')
clerkPhoneNum = int(input())
    
#관리자 테이블에 관리자 정보 입력하기
sql = "INSERT IGNORE INTO 관리자 VALUES (%s, %s, %s, %s, %s, %s)"
cursor.execute(sql, (clerkName, clerkNum, clerkSsn, clerkAddress, clerkPhoneNum, bankNum))
cursor.fetchall()
connection.commit()
while 1:
    print('업무를 선택하세요. 고객응대/거래내역관리/사용자관리/계좌관리/퇴사/지점관리')
    purpose = input()
    if purpose == '고객응대':
        print('고객이 사용자등록을 하고자 합니다.\n고객에게서 이름, 주민번호, 연락처, 주소 정보를 얻어 입력하세요')
        print('사용자 이름을 입력하세요')
        aHName = input()
        print('사용자 주민번호를 입력하세요')
        aHSsn = int(input())
        print('사용자 연락처를 입력하세요')
        aHPhoneNum = int(input())
        print('사용자 주소를 입력하세요')
        aHAddress = input()
        print('사용자등록번호를 입력하세요')
        aHNum = int(input())

        #사용자 테이블에 사용자 정보 입력하기
        sql = "INSERT INTO 사용자 VALUES (%s, %s, %s, %s, %s)"
        cursor.execute(sql, (aHName, aHNum, aHSsn, aHPhoneNum, aHAddress))
        cursor.fetchall()
        connection.commit()

        #사용자관리 테이블에 정보 입력하기
        sql = "INSERT INTO 사용자관리 VALUES (%s, %s)"
        cursor.execute(sql, (clerkNum, aHNum))
        cursor.fetchall()
        connection.commit()

        while 1:
            print('사용자가 보고자하는 업무가 무엇입니까')
            print('계좌개설/계좌삭제/입금/출금')
            purpose = input()
            if purpose == '계좌개설':
                print('계좌번호를 지정하세요')
                accountNum = int(input())
                openingDate = datetime.date.today()
                print('계좌비밀번호를 지정하세요')
                accountPW = int(input())
                balance = 0

                #계좌 테이블에 계좌 정보 입력하기
                sql = "INSERT INTO 계좌 VALUES (%s, %s, %s, %s, %s, %s, %s)"
                cursor.execute(sql, (accountNum, openingDate, accountPW, balance, aHNum, aHNum, aHNum))
                cursor.fetchall()
                connection.commit()

                #계좌관리 테이블에 정보 입력하기
                sql = "INSERT INTO 계좌관리 VALUES (%s, %s)"
                cursor.execute(sql, (accountNum, clerkNum))
                cursor.fetchall()
                connection.commit()

            elif purpose == '계좌삭제':
                print('다음 ' + aHName + '의 계좌 중 삭제할 계좌번호를 입력하세요 (계좌번호, 잔액)으로 보여집니다')
                sql = "SELECT 계좌번호, 잔액 FROM 계좌 WHERE 개설예금주 = %s"
                cursor.execute(sql, aHNum)
                result = cursor.fetchall()
                for t in result:
                    print(t)
                connection.commit()
                accountNumtoDelete = int(input())


                #거래기록 테이블에 정보 삭제하기
                sql = "DELETE FROM 거래기록 WHERE 거래계좌번호 = %s "
                cursor.execute(sql, accountNumtoDelete)
                cursor.fetchall()
                connection.commit()

                #계좌관리 테이블에 정보 삭제하기
                sql = "DELETE FROM 계좌관리 WHERE 계좌번호 = %s"
                cursor.execute(sql, accountNumtoDelete)
                cursor.fetchall()
                connection.commit()
                
                #계좌 테이블에 계좌 정보 삭제하기
                sql = "DELETE FROM 계좌 WHERE 계좌번호 = %s"
                cursor.execute(sql, accountNumtoDelete)
                cursor.fetchall()
                connection.commit()
                
            elif purpose == '입금':
                print('다음 ' + aHName + '의 계좌 중 입금할 계좌의 계좌번호를 입력하세요 (계좌번호, 잔액)으로 보여집니다')
                sql = "SELECT 계좌번호, 잔액 FROM 계좌 WHERE 개설예금주 = %s"
                cursor.execute(sql, aHNum)
                result = cursor.fetchall()
                for t in result:
                    print(t)
                connection.commit()
                accountNumtoDeposit= int(input())
                print('입금할 금액을 입력하세요')
                amount = int(input())
                print('거래번호를 입력하세요')
                tNum = int(input())
                tDate = datetime.date.today()
                
                #계좌 테이블에 계좌 정보 수정하기
                sql = "UPDATE 계좌 SET 잔액 = 잔액 + %s WHERE 계좌번호 = %s"
                cursor.execute(sql, (amount, accountNumtoDeposit))
                cursor.fetchall()
                connection.commit()

                #거래기록 테이블에 거래기록 입력하기
                sql = "INSERT INTO 거래기록 VALUES (%s, %s, %s, %s)"
                cursor.execute(sql, (accountNumtoDeposit, tNum, amount, tDate))
                cursor.fetchall()
                connection.commit()
                
            elif purpose == '출금':
                print('다음 ' + aHName + '의 계좌 중 출금할 계좌의 계좌번호를 입력하세요. (계좌번호, 잔액)으로 보여집니다')
                sql = "SELECT 계좌번호, 잔액 FROM 계좌 WHERE 개설예금주 = %s"
                cursor.execute(sql, aHNum)
                result = cursor.fetchall()
                for t in result:
                    print(t)
                connection.commit()
                accountNumtoWithdraw = int(input())

                print('선택한 계좌 내 잔액은 다음과 같습니다')
                sql = "SELECT 잔액 FROM 계좌 WHERE 계좌번호 = %s"
                cursor.execute(sql, accountNumtoWithdraw)
                result = cursor.fetchall()
                print(result)
                connection.commit()
                print('출금할 금액을 입력하세요')
                amount = int(input())
                print('거래번호를 입력하세요')
                tNum = int(input())
                tDate = datetime.date.today()
           
                sql = "SELECT 잔액 FROM 계좌 WHERE 계좌번호 = %s and (%s <= 잔액)"
                cursor.execute(sql, (accountNumtoWithdraw, amount))
                result = cursor.fetchall()
                print('출금이 성공했습니다.')
                    
                #계좌 테이블에 계좌 정보 수정하기
                sql = "UPDATE 계좌 SET 잔액 = 잔액 - %s WHERE 계좌번호 = %s"
                cursor.execute(sql, (amount, accountNumtoWithdraw))
                cursor.fetchall()
                connection.commit()
                
                print('출금 후 잔액은 다음과 같습니다.')
                sql = "SELECT 잔액 FROM 계좌 WHERE 계좌번호 = %s"
                cursor.execute(sql, accountNumtoWithdraw)
                result = cursor.fetchall()
                print(result)


                #거래기록 테이블에 거래기록 입력하기
                sql = "INSERT INTO 거래기록 VALUES (%s, %s, %s, %s)"
                cursor.execute(sql, (accountNumtoWithdraw, tNum, amount, tDate))
                cursor.fetchall()
                connection.commit()

            print('고객응대관련 다른업무를 더 보시겠습니까?(Y/N)')
            answer = input()
            if answer == 'N':
                break
    elif purpose == '거래내역관리':
        print('소속은행에서 관리중인 거래내역는 다음과 같습니다(계좌번호, 거래번호)')
        sql = "SELECT 거래계좌번호, 거래번호 FROM 은행, 관리자, 계좌관리, 계좌, 거래기록 WHERE 은행번호 = %s and 은행번호 = 근무은행번호 and 관리자등록번호 = 관리자번호 and 계좌관리.계좌번호 = 계좌.계좌번호 and 계좌.계좌번호 = 거래계좌번호"
        cursor.execute(sql, bankNum)
        result = cursor.fetchall()
        connection.commit()
        print(result)
        print('관리할 거래기록의 계좌번호을 선택해주세요')
        answer = int(input())
        print('관리할 거래기록의 거래번호을 선택해주세요')
        answer1 = int(input())
        print('변경할 항목을 선택하세요. 거래계좌번호/거래번호/거래금액/거래내역제거')
        answer2 = input()
        if answer2 == '거래계좌번호':
            print('어떤값으로 변경할지 입력하세요')
            answer3 = int(input())
            sql = "UPDATE 거래기록 SET %s = %s WHERE 거래계좌번호 = %s and 거래번호 = %s"
            cursor.execute(sql, (answer2, answer3, answer, answer1))
            cursor.fetchall()
            connection.commit()
        elif answer2 == '거래번호':
            print('어떤값으로 변경할지 입력하세요')
            answer3 = int(input())
            sql = "UPDATE 거래기록 SET 거래번호 = %s WHERE 거래계좌번호 = %s and 거래번호 = %s"
            cursor.execute(sql, (answer3, answer, answer1))
            cursor.fetchall()
            connection.commit()
        elif answer2 == '거래금액':
            print('어떤값으로 변경할지 입력하세요')
            answer3 = int(input())
            sql = "UPDATE 거래기록 SET 거래금액 = %s WHERE 거래계좌번호 = %s and 거래번호 = %s"
            cursor.execute(sql, (answer3, answer, answer1))
            cursor.fetchall()
            connection.commit()
        elif answer2 == '거래내역제거':
            sql = "DELETE FROM 거래기록 WHERE 거래계좌번호 = %s and 거래번호 = %s"
            cursor.execute(sql, (answer, answer1))
            cursor.fetchall()
            connection.commit()
        
    elif purpose == '사용자관리':
        print('소속된 은행의 사용자는 다음과 같습니다(사용자이름, 사용자등록번호)로 나타납니다.')
        sql = "SELECT DISTINCT 사용자이름, 사용자등록번호 FROM 사용자, 은행, 관리자, 사용자관리 WHERE 은행번호 = %s and 은행번호 = 근무은행번호 and 관리자등록번호 = 관리자번호 and 사용자번호 = 사용자등록번호"
        cursor.execute(sql, bankNum)
        result = cursor.fetchall()
        connection.commit()
        print(result)
        print('관리할 사용자의 사용자등록번호를 선택해주세요')
        answer = int(input())
        sql = "INSERT IGNORE INTO 사용자관리 VALUES (%s, %s)"
        cursor.execute(sql,(clerkNum, answer))
        cursor.fetchall()
        connection.commit()
        print('사용자를 어떻게 관리할지 선택하세요. 사용자이름변경/사용자주민등록번호변경/사용자연락처변경/사용자주소변경/사용자제거')
        answer2 = input()
        if answer2 == '사용자이름변경':
            print('변경 이름을 입력하세요')
            answer3 = input()
            sql = "UPDATE 사용자 SET 사용자이름 = %s WHERE 사용자등록번호 = %s"
            cursor.execute(sql, (answer3, answer))
            cursor.fetchall()
            connection.commit()
        elif answer2 == '사용자주민등록번호변경':
            print('변경 주민등록번호를 입력하세요')
            answer3 = int(input())
            sql = "UPDATE 사용자 SET 주민등록번호 = %s WHERE 사용자등록번호 = %s"
            cursor.execute(sql, (answer3, answer))
            cursor.fetchall()
            connection.commit()
        elif answer2 == '사용자연락처변경':
            print('변경 연락처를 입력하세요')
            answer3 = int(input())
            sql = "UPDATE 사용자 SET 연락처 = %s WHERE 사용자등록번호 = %s"
            cursor.execute(sql, (answer3, answer))
            cursor.fetchall()
            connection.commit()
        elif answer2 == '사용자주소변경':
            print('변경 주소를 입력하세요')
            answer3 = input()
            sql = "UPDATE 사용자 SET 주소 = %s WHERE 사용자등록번호 = %s"
            cursor.execute(sql, (answer3, answer))
            cursor.fetchall()
            connection.commit()
        elif answer2 == '사용자제거':
            sql = "DELETE FROM 사용자 WHERE 사용자등록번호 = %s"
            cursor.execute(sql, (answer3, answer))
            cursor.fetchall()
            connection.commit()

            
    elif purpose == '계좌관리':
        print('소속된 은행의 계좌는 다음과 같습니다')
        sql = "SELECT 계좌.계좌번호 FROM 계좌, 은행, 관리자, 계좌관리 WHERE 은행번호 = %s and 은행번호 = 근무은행번호 and 관리자등록번호 = 관리자번호 and 계좌관리.계좌번호 = 계좌.계좌번호"
        cursor.execute(sql, bankNum)
        result = cursor.fetchall()
        connection.commit()
        print(result)
        print('관리할 계좌를 선택해주세요')
        answer = int(input())
        sql = "INSERT IGNORE INTO 계좌관리 VALUES (%s, %s)"
        cursor.execute(sql,(clerkNum, answer))
        cursor.fetchall()
        connection.commit()
        print('계좌를 어떻게 관리할지 선택하세요. 비밀번호변경/잔액변경/예금주변경')
        answer2 = input()
        if answer2 == '비밀번호변경':
            print('변경 비밀번호를 입력하세요')
            answer3 = int(input())
            sql = "UPDATE 계좌 SET 비밀번호 = %s WHERE 계좌번호 = %s"
            cursor.execute(sql, (answer3, answer))
            cursor.fetchall()
            connection.commit()
        elif answer2 == '잔액변경':
            print('변경 잔액을 입력하세요')
            answer3 = int(input())
            sql = "UPDATE 계좌 SET 잔액 = %s WHERE 계좌번호 = %s"
            cursor.execute(sql, (answer3, answer))
            cursor.fetchall()
            connection.commit()
        elif answer2 == '예금주변경':
            print('변경 비밀번호를 입력하세요')
            answer3 = input()
            sql = "UPDATE 계좌 SET 개설예금주 = %s, 삭제예금주 = %s, 입출금예금주 = %s WHERE 계좌번호 = %s"
            cursor.execute(sql, (answer3, answer3, answer3, answer))
            cursor.fetchall()
            connection.commit()
        
    elif purpose == '퇴사':
        sql = "DELETE FROM 사용자관리 WHERE 관리자번호 = %s"
        cursor.execute(sql, clerkNum)
        cursor.fetchall()
        connection.commit()
        sql = "DELETE FROM 계좌관리 WHERE 관리자번호 = %s"
        cursor.execute(sql, clerkNum)
        cursor.fetchall()
        connection.commit()
        sql = "DELETE FROM 관리자 WHERE 관리자등록번호 = %s"
        cursor.execute(sql, clerkNum)
        cursor.fetchall()
        connection.commit()
        
    elif purpose == '지점관리':
        print('소속된 은행의 지점은 다음과 같습니다')
        sql = "SELECT 지점이름 FROM 은행, 지점, 관리자 WHERE 관리자등록번호 = %s and 근무은행번호 = 은행번호 and 소속은행번호 = 은행번호"
        cursor.execute(sql, clerkNum)
        result = cursor.fetchall()
        connection.commit()
        print(result)
        print('관리할 지점을 선택해주세요')
        answer = input()
        print('관리할 지점을 어떻게 처리할지 입력하세요. 이름변경/주소이전/폐점')
        answer2 = input()
        if answer2 == '이름변경':
            print('변경할 이름을 입력하세요')
            answer3 = input()
            sql = "UPDATE 지점 SET 지점이름 = %s WHERE 지점이름 = %s"
            cursor.execute(sql, (answer3, answer))
            cursor.fetchall()
            connection.commit()
        elif answer2 == '주소이전':
            print('이전할 주소를 입력하세요')
            answer3 = input()
            sql = "UPDATE 지점 SET 지점주소 = %s WHERE 지점이름 = %s"
            cursor.execute(sql, (answer3, answer))
            cursor.fetchall()
            connection.commit()
        elif answer2 == '폐점':
            sql = "DELETE FROM 지점 WHERE 지점이름 = %s"
            cursor.execute(sql, answer)
            cursor.fetchall()
            connection.commit()
        
    print('다른 업무를 더 보시겠습니까?(Y/N)')
    answer = input()
    if answer == 'N':
        break
    
connection.close()
